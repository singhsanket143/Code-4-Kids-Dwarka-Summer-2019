## Segment Trees and Lazy Propagation

Refer tutorial for explanation.

```C++
    
    

```
